<?php

return [

    'title' => 'Ayarlar',
    'general' => 'Genel Ayarlar',
    'federation' => 'Federasyonlar',

    'federation_add' => 'Yeni Federasyon Ekle',
    'federation_edit' => 'Federasyon Düzenle',

    'federation_delete' => ':name federasyonu silinecektir, işleme devam edilsin mi?',
    'federation_delete_success' => ':name federasyonu silindi',
    'federation_save_success' => ':name federasyonu kayıt edildi',

    'club_delete' => ':name kulübü silinecektir, işleme devam edilsin mi?',
    'club_delete_success' => ':name kulübü silindi',
    'club_save_success' => ':name kulübü kayıt edildi',

    'general_save_success' => 'Ayarlar başarıyla kayıt edildi'
];
