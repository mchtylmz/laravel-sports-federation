<?php

return [
    'title' => 'Cezalar',
    'add' => 'Ceza Ekle',

    'delete' => 'Kayıt silinecektir, işleme devam edilsin mi?',

    'save_success' => ':reason başarıyla kayıt edildi',
    'delete_success' => ':reason cezası silindi',
];
