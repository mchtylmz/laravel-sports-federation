<?php

return [

    'title' => 'Bilgi Bankası',
    'add' => 'Ekle',

    'type' => 'Kişi Tipi',

    'nationality' => 'Uyruk',
    'license_no' => 'Lisans No',

    'player' => 'Oyuncu',
    'referee' => 'Hakem',
    'coach' => 'Antrenör',
    'racer' => 'Yarışçı',
    'school' => 'Okul Sporları',


    'delete' => 'Kayıt silinecektir, işleme devam edilsin mi?',

    'save_success' => ':fullname başarıyla kayıt edildi',
    'delete_success' => ':fullname cezası silindi',
];
