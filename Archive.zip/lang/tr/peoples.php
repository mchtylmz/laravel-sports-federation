<?php

return [

    'title' => 'Bilgi Bankası',
    'add' => 'Ekle',

    'type' => 'Tip',

    'nationality' => 'Uyruk',
    'license_no' => 'Lisans No',

    'player' => 'Oyuncu',
    'referee' => 'Hakem',
    'coach' => 'Antrenör',
    'racer' => 'Yarışçı',
    'school' => 'Okul Sporları',

    'noAdult' => '18 Yaşından Büyük',
    'adult18' => '18 Yaşından Küçük, Veli Onaylı',
    'under18' => '18 Yaşından Küçük, Veli Onaylı Yok',

    'delete' => 'Kayıt silinecektir, işleme devam edilsin mi?',

    'save_success' => ':fullname başarıyla kayıt edildi',
    'delete_success' => ':fullname cezası silindi',
];
