@extends('layouts.app')
@section('content')
    <div class="py-4 text-center">
        <!-- Error Header -->
        <h1 class="display-1 fw-bolder text-danger">
            403
        </h1>
        <h2 class="h4 fw-normal text-danger mb-5">
            Üzgünüz ama bu sayfaya erişim izniniz yok..
        </h2>
        <!-- END Error Header -->
    </div>
@endsection
