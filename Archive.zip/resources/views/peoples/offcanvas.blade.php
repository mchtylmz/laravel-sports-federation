detay
